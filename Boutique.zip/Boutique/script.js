function changeQuantity(change) {
    if (quantity + change > 0) {
      quantity += change;
      document.getElementById('quantityDisplay').textContent = quantity;
    }
  }
  const productData = {
    id: 1,
    name: "Floral Dress",
    price: 120.00,
    description: "A beautiful floral dress, perfect for any occasion.",
    image: "https://via.placeholder.com/450x600?text=Floral+Dress",
    additionalDetails: "This dress is made from premium fabric with an elegant floral design. Available in various sizes."
  };
  
  function loadProductDetails(product) {
    document.getElementById('productTitle').textContent = product.name;
    document.getElementById('productPrice').textContent = `$${product.price.toFixed(2)}`;
    document.getElementById('productDescription').textContent = product.description;
    document.getElementById('productImage').src = product.image;
    document.getElementById('additionalDetails').textContent = product.additionalDetails;
  }
  let quantity = 1;

function changeQuantity(change) {
  if (quantity + change > 0) {
    quantity += change;
    document.getElementById('quantityDisplay').textContent = quantity;
  }
}
function addToCart() {
  const size = document.getElementById('size').value;
  alert(`Added ${quantity} x ${productData.name} (Size: ${size}) to cart.`);
}
